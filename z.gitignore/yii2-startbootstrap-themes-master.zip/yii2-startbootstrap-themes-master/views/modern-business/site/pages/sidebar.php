<?php
/**
 * sidebar.php
 *
 * @author Pedro Plowman
 * @copyright Copyright &copy; Pedro Plowman, 2017
 * @link https://github.com/p2made
 * @package yii2-startbootstrap-themes
 * @license MIT
 */

/* @var $this yii\web\View */

use yii\bootstrap\Html;
use yii\widgets\Breadcrumbs;
use p2m\helpers\FA;

$this->title = 'Sidebar Page';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="container">

	<!-- Page Heading/Breadcrumbs -->
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header"><?= Html::encode($this->title) ?>
				<small>Subheading</small>
			</h1>
<?= Breadcrumbs::widget([
	'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
]) ?>
		</div>
	</div>
	<!-- /.row -->

	<!-- Content Row -->
	<div class="row">
		<!-- Sidebar Column -->
		<div class="col-md-3">
			<div class="list-group">
				<a href="index.html" class="list-group-item">Home</a>
				<a href="about.html" class="list-group-item">About</a>
				<a href="services.html" class="list-group-item">Services</a>
				<a href="contact.html" class="list-group-item">Contact</a>
				<a href="portfolio-1-col.html" class="list-group-item">1 Column Portfolio</a>
				<a href="portfolio-2-col.html" class="list-group-item">2 Column Portfolio</a>
				<a href="portfolio-3-col.html" class="list-group-item">3 Column Portfolio</a>
				<a href="portfolio-4-col.html" class="list-group-item">4 Column Portfolio</a>
				<a href="portfolio-item.html" class="list-group-item">Single Portfolio Item</a>
				<a href="blog-home-1.html" class="list-group-item">Blog Home 1</a>
				<a href="blog-home-2.html" class="list-group-item">Blog Home 2</a>
				<a href="blog-post.html" class="list-group-item">Blog Post</a>
				<a href="full-width.html" class="list-group-item">Full Width Page</a>
				<a href="sidebar.html" class="list-group-item active">Sidebar Page</a>
				<a href="faq.html" class="list-group-item">FAQ</a>
				<a href="404.html" class="list-group-item">404</a>
				<a href="pricing.html" class="list-group-item">Pricing Table</a>
			</div>
		</div>
		<!-- Content Column -->
		<div class="col-md-9">
			<h2>Section Heading</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta, et temporibus, facere perferendis veniam beatae non debitis, numquam blanditiis necessitatibus vel mollitia dolorum laudantium, voluptate dolores iure maxime ducimus fugit.</p>
		</div>
	</div>
	<!-- /.row -->

	<?= $this->render('../_footer.php') ?>

	<!-- Page Code Location - remove in production -->
	<div class="row">
		<div class="col-lg-12">
			<code><?= __FILE__ ?></code>
		</div>
	</div>

</div>
